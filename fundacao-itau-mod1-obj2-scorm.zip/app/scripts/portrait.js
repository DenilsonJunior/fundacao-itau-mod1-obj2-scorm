events.on("ready",function(){function i(){$(window).height()<$(window).width()?$(".portrait").css("display","none"):setTimeout(function(){$(".portrait").css("display","block")},200)}i(),$(window).resize(function(){i()})});
//# sourceMappingURL=portrait.js.map
